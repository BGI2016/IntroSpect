date
echo "Runing A.Peptides_Cluster.sh"
sh /ldfssz1/ST_PRECISION/USER/zhangle2/soft/IntroSpect-1.0/TEST/./analysis/0.shell/A.Peptides_Cluster.sh
echo "Runing B.TrainingSet_Preparation.sh"
sh /ldfssz1/ST_PRECISION/USER/zhangle2/soft/IntroSpect-1.0/TEST/./analysis/0.shell/B.TrainingSet_Preparation.sh
echo "Runing C.Motif_Learning.sh"
sh /ldfssz1/ST_PRECISION/USER/zhangle2/soft/IntroSpect-1.0/TEST/./analysis/0.shell/C.Motif_Learning.sh
echo "Runing D.SearchSpace_Filtering.sh"
sh /ldfssz1/ST_PRECISION/USER/zhangle2/soft/IntroSpect-1.0/TEST/./analysis/0.shell/D.SearchSpace_Filtering.sh
date
