#perl ../DB2SS.pl -file HumanProteinDatabase.test-1000.fasta -prefix test-1000 -outdir ./test-1000/ -minLen 8 -maxLen 12
perl ../IntroSpect.pl -ss ./test-1000/test-1000.searchSpace.ss -pep conventional.identified.pep.txt -prefix test-1000 -gc ./gibbscluster -outdir ./analysis
